import express from "express";
import { createServer as createViteServer } from "vite";
import { WebSocketServer, WebSocket } from "ws";
import http from "http";
import axios from "axios";
import {
  EMA,
  SMA,
  RSI,
  StochasticRSI,
  BollingerBands,
} from "technicalindicators";

const PORT = 3000;
const SYMBOL = "XRP_USDT";
const MEXC_WS_URL = "wss://contract.mexc.com/edge";
const MEXC_REST_URL = "https://contract.mexc.com/api/v1/contract/kline";

interface Kline {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface Indicators {
  ema5: number[];
  ema24: number[];
  ma20: number[];
  sma55: number[];
  ema100: number[];
  sma120: number[];
  ema200: number[];
  rsi: number[];
  stochRSI: { k: number; d: number }[];
  bb: { upper: number; middle: number; lower: number }[];
}

class SentinelEngine {
  private klines5m: Kline[] = [];
  private klines15m: Kline[] = [];
  private indicators5m: Indicators | null = null;
  private indicators15m: Indicators | null = null;
  private lastSignal: any = null;
  private lastHistoricalSignals: any[] = [];
  private clients: Set<WebSocket> = new Set();

  constructor() {
    this.init();
  }

  private async init() {
    console.log("Initializing Sentinel Engine...");
    await this.fetchHistoricalData();
    this.connectMEXC();
  }

  private async fetchHistoricalData() {
    try {
      const fetchKlines = async (interval: string) => {
        const response = await axios.get(`${MEXC_REST_URL}/${SYMBOL}`, {
          params: { interval, limit: 1000 },
        });
        if (response.data.success) {
          return response.data.data.time.map((t: number, i: number) => ({
            time: t * 1000,
            open: response.data.data.open[i],
            high: response.data.data.high[i],
            low: response.data.data.low[i],
            close: response.data.data.close[i],
            volume: response.data.data.vol[i],
          }));
        }
        return [];
      };

      this.klines5m = await fetchKlines("Min5");
      this.klines15m = await fetchKlines("Min15");
      this.calculateAll();
      this.runHistoricalBacktest();
      console.log("Historical data fetched and indicators calculated.");
    } catch (error) {
      console.error("Error fetching historical data:", error);
    }
  }

  private calculateIndicators(klines: Kline[]): Indicators {
    const closes = klines.map((k) => k.close);
    const highs = klines.map((k) => k.high);
    const lows = klines.map((k) => k.low);

    const stochInput = {
      values: closes,
      rsiPeriod: 14,
      stochasticPeriod: 14,
      kPeriod: 3,
      dPeriod: 3,
    };

    const bbInput = {
      period: 20,
      values: closes,
      stdDev: 2,
    };

    const stochRSIResult = StochasticRSI.calculate(stochInput);
    
    return {
      ema5: EMA.calculate({ period: 5, values: closes }),
      ema24: EMA.calculate({ period: 24, values: closes }),
      ma20: SMA.calculate({ period: 20, values: closes }),
      sma55: SMA.calculate({ period: 55, values: closes }),
      ema100: EMA.calculate({ period: 100, values: closes }),
      sma120: SMA.calculate({ period: 120, values: closes }),
      ema200: EMA.calculate({ period: 200, values: closes }),
      rsi: RSI.calculate({ period: 14, values: closes }),
      stochRSI: stochRSIResult.map((s: any) => ({
        k: s.stochK ?? s.k ?? 0,
        d: s.stochD ?? s.d ?? 0,
      })),
      bb: BollingerBands.calculate(bbInput).map((b: any) => ({
        upper: b.upper,
        middle: b.middle,
        lower: b.lower,
      })),
    };
  }

  private calculateAll() {
    this.indicators5m = this.calculateIndicators(this.klines5m);
    this.indicators15m = this.calculateIndicators(this.klines15m);
    this.checkSignals();
  }

  private async sendTelegram(msg: string) {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (token && chatId) {
      try {
        await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
          chat_id: chatId,
          text: msg,
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [[{ text: "Open MEXC", url: "https://www.mexc.com/futures/XRP_USDT" }]]
          }
        });
      } catch (e) {
        console.error("Telegram error:", e);
      }
    }
  }

  private runHistoricalBacktest() {
    console.log("Running optimized historical backtest...");
    const historicalSignals: any[] = [];
    
    // Calculate indicators for the full dataset once
    const ind5m = this.calculateIndicators(this.klines5m);
    const ind15m = this.calculateIndicators(this.klines15m);
    
    const minLength = Math.min(
      this.klines5m.length, 
      this.klines15m.length,
      ind5m.ema200.length,
      ind15m.ema200.length
    );

    // We need to align indices. Indicators usually have a offset due to period.
    // EMA 200 will have length = klines.length - 199
    const offset5m = this.klines5m.length - ind5m.ema200.length;
    const offset15m = this.klines15m.length - ind15m.ema200.length;

    for (let i = 10; i < ind15m.ema200.length; i++) {
      // Map back to klines indices
      const k5Idx = i + (ind5m.ema200.length - ind15m.ema200.length); 
      if (k5Idx < 1) continue;

      const last5m = this.klines5m[k5Idx + offset5m];
      const last15m = this.klines15m[i + offset15m];

      if (!last5m || !last15m) continue;

      const ema200_15m = ind15m.ema200[i];
      const sma120_15m = ind15m.sma120[i];
      const stoch15m = ind15m.stochRSI[i];
      const stoch15m_prev = ind15m.stochRSI[i - 1];

      const rsi5m = ind5m.rsi[k5Idx];
      const rsi5m_prev = ind5m.rsi[k5Idx - 1];
      const bb5m = ind5m.bb[k5Idx];

      if (!stoch15m || !stoch15m_prev || !bb5m) continue;

      let signal: any = null;

      // Stricter LONG Logic for backtest
      const isTrendLong = last15m.close > ema200_15m;
      const isRibbonLong = last15m.close > sma120_15m;
      const isStochLong = stoch15m.k > stoch15m.d && stoch15m_prev.k <= stoch15m_prev.d && stoch15m.k < 25;
      
      if (isTrendLong && isRibbonLong && isStochLong) {
        signal = {
          type: "LONG",
          price: last5m.close,
          time: last5m.time,
          confidence: "NORMAL",
          sl: last5m.close * 0.992,
          tp: last5m.close * 1.015,
        };
      }

      // Stricter SHORT Logic for backtest
      const isTrendShort = last15m.close < ema200_15m;
      const isRibbonShort = last15m.close < sma120_15m;
      const isStochShort = stoch15m.k < stoch15m.d && stoch15m_prev.k >= stoch15m_prev.d && stoch15m.k > 75;
      
      if (isTrendShort && isRibbonShort && isStochShort) {
        signal = {
          type: "SHORT",
          price: last5m.close,
          time: last5m.time,
          confidence: "NORMAL",
          sl: last5m.close * 1.008,
          tp: last5m.close * 0.985,
        };
      }

      if (signal) {
        const lastSig = historicalSignals[historicalSignals.length - 1];
        const timeGap = signal.time - (lastSig?.time || 0);
        const priceDiff = lastSig ? Math.abs(signal.price - lastSig.price) / lastSig.price : 1;

        // 4 hour gap or 1% price move for historical variety
        if (!lastSig || (timeGap > 14400000 || priceDiff > 0.01)) {
          historicalSignals.push(signal);
        }
      }
    }
    
    this.lastHistoricalSignals = historicalSignals.slice(-20).reverse();
    
    // Fallback if no signals found in backtest
    if (this.lastHistoricalSignals.length === 0) {
      this.lastHistoricalSignals.push({
        type: "LONG",
        price: this.klines5m[this.klines5m.length - 1]?.close || 0,
        time: Date.now(),
        confidence: "NORMAL",
        sl: 0,
        tp: 0,
        isSystem: true
      });
    }
    
    console.log(`Backtest complete. Found ${this.lastHistoricalSignals.length} historical signals.`);
  }

  private getSignalFromData(k5m: Kline[], k15m: Kline[], ind5m: Indicators, ind15m: Indicators) {
    const last5m = k5m[k5m.length - 1];
    const last15m = k15m[k15m.length - 1];

    const ema200_15m = ind15m.ema200[ind15m.ema200.length - 1];
    const sma120_15m = ind15m.sma120[ind15m.sma120.length - 1];
    const stoch15m = ind15m.stochRSI[ind15m.stochRSI.length - 1];
    const stoch15m_prev = ind15m.stochRSI[ind15m.stochRSI.length - 2];

    const rsi5m = ind5m.rsi[ind5m.rsi.length - 1];
    const rsi5m_prev = ind5m.rsi[ind5m.rsi.length - 2];
    const bb5m = ind5m.bb[ind5m.bb.length - 1];

    const rsi15m = ind15m.rsi[ind15m.rsi.length - 1];
    const ema200_5m = ind5m.ema200[ind5m.ema200.length - 1];

    if (!stoch15m || !stoch15m_prev || !bb5m) return null;

    // LONG Logic: Multi-timeframe trend + StochRSI Cross + RSI Support
    const isTrendLong = last15m.close > ema200_15m && last5m.close > ema200_5m;
    const isRibbonLong = last15m.close > sma120_15m;
    const isStochLong = stoch15m.k > stoch15m.d && stoch15m_prev.k <= stoch15m_prev.d && stoch15m.k < 25;
    const isRSILong = rsi15m > 45; // Ensure we aren't catching a falling knife
    
    if (isTrendLong && isRibbonLong && isStochLong && isRSILong) {
      const isHighProb = last5m.low <= bb5m.lower * 1.002 && rsi5m > 30 && rsi5m < 45;
      return {
        type: "LONG",
        price: last5m.close,
        time: Date.now(),
        confidence: isHighProb ? "HIGH" : "NORMAL",
        sl: Math.min(ind5m.sma55[ind5m.sma55.length - 1], last5m.close * 0.992),
        tp: last5m.close * 1.015,
      };
    }

    // SHORT Logic: Multi-timeframe trend + StochRSI Cross + RSI Resistance
    const isTrendShort = last15m.close < ema200_15m && last5m.close < ema200_5m;
    const isRibbonShort = last15m.close < sma120_15m;
    const isStochShort = stoch15m.k < stoch15m.d && stoch15m_prev.k >= stoch15m_prev.d && stoch15m.k > 75;
    const isRSIShort = rsi15m < 55;
    
    if (isTrendShort && isRibbonShort && isStochShort && isRSIShort) {
      const isHighProb = last5m.high >= bb5m.upper * 0.998 && rsi5m < 70 && rsi5m > 55;
      return {
        type: "SHORT",
        price: last5m.close,
        time: Date.now(),
        confidence: isHighProb ? "HIGH" : "NORMAL",
        sl: Math.max(ind5m.sma55[ind5m.sma55.length - 1], last5m.close * 1.008),
        tp: last5m.close * 0.985,
      };
    }

    return null;
  }

  private checkSignals() {
    if (!this.indicators5m || !this.indicators15m) return;
    const signal = this.getSignalFromData(this.klines5m, this.klines15m, this.indicators5m, this.indicators15m);
    
    if (!signal) return;

    const isNewType = this.lastSignal?.type !== signal.type;
    const timeSinceLast = Date.now() - (this.lastSignal?.time || 0);
    const priceDiff = this.lastSignal ? Math.abs(signal.price - this.lastSignal.price) / this.lastSignal.price : 1;
    
    // Cooldown: 15 minutes for same type, or significant price movement (0.5%)
    const isCooldownOver = timeSinceLast > 900000 || (isNewType && timeSinceLast > 300000) || priceDiff > 0.005;

    if (isCooldownOver) {
      console.log(`Signal Triggered: ${signal.type} at ${signal.price} (Confidence: ${signal.confidence})`);
      this.lastSignal = signal;
      this.broadcast({ type: "SIGNAL", data: signal });
      this.sendTelegram(`*XRP SENTINEL ALERT*\nDirection: ${signal.type}\nPrice: ${signal.price}\nTP: ${signal.tp}\nSL: ${signal.sl}\nConfidence: ${signal.confidence}`);
    }
  }

  private connectMEXC() {
    const ws = new WebSocket(MEXC_WS_URL);

    ws.on("open", () => {
      console.log("Connected to MEXC WebSocket");
      ws.send(JSON.stringify({ method: "sub.kline", param: { symbol: SYMBOL, interval: "Min5" } }));
      ws.send(JSON.stringify({ method: "sub.kline", param: { symbol: SYMBOL, interval: "Min15" } }));
    });

    ws.on("message", (data) => {
      const msg = JSON.parse(data.toString());
      if (msg.channel === "push.kline") {
        const k = msg.data;
        const kline: Kline = {
          time: k.t * 1000,
          open: k.o,
          high: k.h,
          low: k.l,
          close: k.c,
          volume: k.v,
        };

        if (msg.symbol === SYMBOL) {
          if (msg.interval === "Min5") {
            this.updateKlines(this.klines5m, kline);
          } else if (msg.interval === "Min15") {
            this.updateKlines(this.klines15m, kline);
          }
          this.calculateAll();
          this.broadcast({
            type: "UPDATE",
            data: {
              price: kline.close,
              klines5m: this.getChartData(this.klines5m, this.indicators5m),
              klines15m: this.getChartData(this.klines15m, this.indicators15m),
              indicators5m: this.indicators5m ? this.getLatestIndicators(this.indicators5m) : null,
              indicators15m: this.indicators15m ? this.getLatestIndicators(this.indicators15m) : null,
            },
          });
        }
      }
    });

    ws.on("close", () => {
      console.log("MEXC WebSocket closed. Reconnecting...");
      setTimeout(() => this.connectMEXC(), 5000);
    });
  }

  private getChartData(klines: Kline[], ind: Indicators | null) {
    if (!ind) return klines.slice(-60);
    const slice = klines.slice(-60);
    const offset = klines.length - ind.ma20.length;
    const offsetEma = klines.length - ind.ema200.length;

    return slice.map((k, i) => {
      const globalIdx = klines.length - slice.length + i;
      const maIdx = globalIdx - offset;
      const emaIdx = globalIdx - offsetEma;

      return {
        ...k,
        ma20: maIdx >= 0 ? ind.ma20[maIdx] : null,
        ema200: emaIdx >= 0 ? ind.ema200[emaIdx] : null,
        // For candlestick rendering
        isUp: k.close >= k.open,
        candleBody: [k.open, k.close],
        candleWick: [k.low, k.high]
      };
    });
  }

  private updateKlines(klines: Kline[], newKline: Kline) {
    const last = klines[klines.length - 1];
    if (last && last.time === newKline.time) {
      klines[klines.length - 1] = newKline;
    } else {
      klines.push(newKline);
      if (klines.length > 1000) klines.shift();
    }
  }

  private getLatestIndicators(ind: Indicators) {
    return {
      ema5: ind.ema5[ind.ema5.length - 1] || 0,
      ema24: ind.ema24[ind.ema24.length - 1] || 0,
      ma20: ind.ma20[ind.ma20.length - 1] || 0,
      sma55: ind.sma55[ind.sma55.length - 1] || 0,
      ema100: ind.ema100[ind.ema100.length - 1] || 0,
      sma120: ind.sma120[ind.sma120.length - 1] || 0,
      ema200: ind.ema200[ind.ema200.length - 1] || 0,
      rsi: ind.rsi[ind.rsi.length - 1] || 0,
      stochRSI: ind.stochRSI[ind.stochRSI.length - 1] || { k: 0, d: 0 },
      bb: ind.bb[ind.bb.length - 1] || { upper: 0, middle: 0, lower: 0 },
    };
  }

  public addClient(ws: WebSocket) {
    this.clients.add(ws);
    ws.send(JSON.stringify({ 
      type: "INIT", 
      data: { 
        price: this.klines5m[this.klines5m.length - 1]?.close,
        historicalSignals: this.lastHistoricalSignals
      } 
    }));
  }

  public removeClient(ws: WebSocket) {
    this.clients.delete(ws);
  }

  private broadcast(msg: any) {
    const data = JSON.stringify(msg);
    this.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });
  const engine = new SentinelEngine();

  wss.on("connection", (ws) => {
    engine.addClient(ws);
    ws.on("close", () => engine.removeClient(ws));
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`XRP SENTINEL Server running on http://localhost:${PORT}`);
  });
}

startServer();
