import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  ShieldCheck, 
  Activity, 
  Clock, 
  Zap, 
  Bell,
  BarChart3,
  Settings,
  Info,
  ExternalLink,
  ChevronRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  Bar,
  BarChart,
  ComposedChart,
  Cell
} from "recharts";
import { format } from "date-fns";
import { toZonedTime } from "date-fns-tz";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Signal {
  type: "LONG" | "SHORT";
  price: number;
  time: number;
  confidence: "HIGH" | "NORMAL";
  sl: number;
  tp: number;
  isSystem?: boolean;
}

interface UpdateData {
  price: number;
  klines5m: any[];
  klines15m: any[];
  indicators5m: any;
  indicators15m: any;
}

export default function App() {
  const [price, setPrice] = useState<number | null>(null);
  const [data, setData] = useState<UpdateData | null>(null);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [balance, setBalance] = useState<number>(1);
  const [risk, setRisk] = useState<number>(1);
  const [connected, setConnected] = useState(false);
  const [timeframe, setTimeframe] = useState<"5M" | "15M">("5M");
  const ws = useRef<WebSocket | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const connect = useCallback(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host;
    ws.current = new WebSocket(`${protocol}//${host}`);

    ws.current.onopen = () => {
      setConnected(true);
      console.log("Connected to Sentinel Server");
    };

    ws.current.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      console.log("WS Message Received:", msg.type, msg.data);
      if (msg.type === "UPDATE") {
        setData(msg.data);
        setPrice(msg.data.price);
      } else if (msg.type === "SIGNAL") {
        setSignals((prev) => [msg.data, ...prev].slice(0, 20));
        playAlert();
      } else if (msg.type === "INIT") {
        setPrice(msg.data.price);
        if (msg.data.historicalSignals && msg.data.historicalSignals.length > 0) {
          console.log("Setting historical signals:", msg.data.historicalSignals.length);
          setSignals(msg.data.historicalSignals);
        }
      }
    };

    ws.current.onclose = () => {
      setConnected(false);
      setTimeout(connect, 3000);
    };
  }, []);

  useEffect(() => {
    connect();
    return () => ws.current?.close();
  }, [connect]);

  const formatTime = (time: number) => {
    const zonedTime = toZonedTime(new Date(time), "Europe/Belgrade");
    return format(zonedTime, "HH:mm:ss");
  };

  const formatTimeShort = (time: number) => {
    const zonedTime = toZonedTime(new Date(time), "Europe/Belgrade");
    return format(zonedTime, "HH:mm");
  };

  const playAlert = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(e => console.log("Audio play failed", e));
    }
  };

  const trend15m = useMemo(() => {
    if (!data?.indicators15m || !price) return "NEUTRAL";
    const ema200 = data.indicators15m.ema200;
    return price > ema200 ? "BULLISH" : "BEARISH";
  }, [data, price]);

  const currentIndicators = useMemo(() => {
    return timeframe === "5M" ? data?.indicators5m : data?.indicators15m;
  }, [data, timeframe]);

  const riskCalc = useMemo(() => {
    if (!price) return null;
    const riskAmount = balance * (risk / 100);
    const slPercent = 0.015; // 1.5% fixed for calc
    const positionSize = riskAmount / slPercent;
    const leverage = 10;
    const margin = positionSize / leverage;
    const liqPrice = trend15m === "BULLISH" ? price * 0.91 : price * 1.09; // Approx 10x liq

    return {
      riskAmount,
      positionSize,
      margin,
      liqPrice
    };
  }, [balance, risk, price, trend15m]);

  return (
    <div className="min-h-screen p-4 md:p-8 space-y-6 max-w-7xl mx-auto">
      <audio ref={audioRef} src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3" />
      
      {/* Header */}
      <header id="main-header" className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
          <h1 className="text-4xl font-display font-bold tracking-tight bg-gradient-to-r from-white to-white/40 bg-clip-text text-transparent">
            XRP SENTINEL <span className="text-cyber-blue font-light">PRO</span>
          </h1>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-white/30 font-mono text-xs tracking-widest uppercase">Powered by LaktusDev</p>
            <div className="flex items-center gap-2">
              <img 
                src="https://picsum.photos/seed/laktus-trading/100/100" 
                alt="LaktusDev Logo" 
                className="h-6 w-auto object-contain opacity-80 rounded-sm border border-white/10"
                referrerPolicy="no-referrer"
              />
              <Zap className="w-3 h-3 text-cyber-green animate-pulse" />
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div id="connection-status" className={cn(
            "flex items-center gap-2 px-4 py-1.5 rounded-full border text-[10px] font-bold tracking-widest uppercase transition-all duration-500",
            connected ? "border-cyber-green/20 bg-cyber-green/5 text-cyber-green" : "border-cyber-red/20 bg-cyber-red/5 text-cyber-red"
          )}>
            <div className={cn("w-1.5 h-1.5 rounded-full", connected ? "bg-cyber-green animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-cyber-red")} />
            {connected ? "Live Network" : "Offline"}
          </div>
          <div id="price-display" className="glass-card px-5 py-2.5 flex items-center gap-4 border-white/10">
            <Activity className="w-4 h-4 text-cyber-blue animate-pulse" />
            <div className="flex flex-col">
              <span className="text-[8px] text-white/40 font-mono uppercase leading-none mb-1">Market Price</span>
              <div className="flex items-baseline gap-1">
                <span className="font-mono text-xl font-bold tracking-tighter">
                  {price ? price.toFixed(4) : "---.----"}
                </span>
                <span className="text-[10px] text-white/20 font-mono">USDT</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Metrics & Risk */}
        <div className="lg:col-span-4 space-y-6">
          {/* Trend Status */}
          <div id="trend-status-card" className={cn(
            "glass-card p-6 relative overflow-hidden group",
            trend15m === "BULLISH" ? "neon-border-green" : "neon-border-red"
          )}>
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              {trend15m === "BULLISH" ? <TrendingUp size={120} /> : <TrendingDown size={120} />}
            </div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-[10px] font-mono uppercase tracking-[0.2em] text-white/40">Trend Analysis (15M)</h3>
              <div className={cn(
                "p-2 rounded-lg bg-white/5",
                trend15m === "BULLISH" ? "text-cyber-green" : "text-cyber-red"
              )}>
                {trend15m === "BULLISH" ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              </div>
            </div>
            <div className={cn(
              "text-4xl font-display font-bold tracking-tight",
              trend15m === "BULLISH" ? "text-cyber-green" : "text-cyber-red"
            )}>
              {trend15m}
            </div>
            <div className="mt-4 flex items-center gap-2 text-[10px] font-mono text-white/20">
              <Info className="w-3 h-3" />
              <span>EMA 200: {data?.indicators15m?.ema200?.toFixed(4) || "..."}</span>
            </div>
          </div>

          {/* Signal Log */}
          <div id="signal-intelligence-card" className="glass-card flex flex-col h-[600px]">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-cyber-green/10">
                  <Bell className="w-4 h-4 text-cyber-green" />
                </div>
                <h3 className="text-xs font-mono uppercase tracking-widest font-bold">Signal Intelligence</h3>
              </div>
              <span className="px-2 py-1 rounded bg-white/5 text-[9px] font-mono text-white/40">{signals.length} ACTIVE</span>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              <AnimatePresence initial={false}>
                {signals.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-white/10 space-y-4">
                    <div className="p-4 rounded-full bg-white/[0.02] border border-white/5">
                      <Zap className="w-8 h-8 opacity-20" />
                    </div>
                    <p className="text-[10px] font-mono uppercase tracking-widest">Scanning Market Confluence...</p>
                  </div>
                ) : (
                  signals.map((sig, i) => (
                    <motion.div
                      key={`${sig.time}-${i}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      id={`signal-item-${i}`}
                      className={cn(
                        "p-4 rounded-xl border bg-white/[0.02] relative group cursor-pointer transition-all duration-300 hover:bg-white/[0.04]",
                        sig.isSystem 
                          ? "border-white/5" 
                          : sig.confidence === "HIGH"
                            ? sig.type === "LONG" ? "border-cyber-green/40 shadow-[0_0_15px_rgba(16,185,129,0.05)]" : "border-cyber-red/40 shadow-[0_0_15px_rgba(239,68,68,0.05)]"
                            : sig.type === "LONG" ? "border-cyber-green/10" : "border-cyber-red/10"
                      )}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center gap-2">
                          <div className={cn(
                            "px-2 py-0.5 rounded text-[9px] font-bold flex items-center gap-1 tracking-wider uppercase",
                            sig.isSystem ? "bg-white/10 text-white" : sig.type === "LONG" ? "bg-cyber-green/20 text-cyber-green" : "bg-cyber-red/20 text-cyber-red"
                          )}>
                            {sig.isSystem ? "SYSTEM" : sig.type}
                            {sig.confidence === "HIGH" && !sig.isSystem && <ShieldCheck className="w-3 h-3" />}
                          </div>
                          {sig.confidence === "HIGH" && !sig.isSystem && (
                            <span className="text-[8px] font-bold text-cyber-blue animate-pulse tracking-widest uppercase">High Prob</span>
                          )}
                        </div>
                        <span className="text-[11px] font-mono text-white/40 font-bold">{formatTime(sig.time)}</span>
                      </div>
                      <div className="flex justify-between items-end">
                        <div>
                          <div className="text-xl font-display font-bold tracking-tight">
                            {sig.isSystem ? "READY" : `$${sig.price?.toFixed(4) || "0.0000"}`}
                          </div>
                          <div className="text-[9px] text-white/30 font-mono uppercase tracking-tighter">
                            {sig.isSystem ? "Engine Status" : "Entry Price"}
                          </div>
                        </div>
                        {!sig.isSystem && (
                          <div className="text-right space-y-1">
                            <div className="text-xs text-cyber-green font-mono flex items-center justify-end gap-1 font-bold">
                              <span className="opacity-40 text-[9px]">TP</span> {sig.tp?.toFixed(4) || "0.0000"}
                            </div>
                            <div className="text-xs text-cyber-red font-mono flex items-center justify-end gap-1 font-bold">
                              <span className="opacity-40 text-[9px]">SL</span> {sig.sl?.toFixed(4) || "0.0000"}
                            </div>
                          </div>
                        )}
                      </div>
                      {!sig.isSystem && (
                        <a 
                          href="https://www.mexc.com/futures/XRP_USDT" 
                          target="_blank" 
                          className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0"
                        >
                          <ExternalLink className="w-3 h-3 text-white/40 hover:text-white" />
                        </a>
                      )}
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Right Column: Charts & Analysis */}
        <div className="lg:col-span-8 space-y-6">
          {/* Main Chart */}
          <div id="momentum-terminal-card" className="glass-card p-6 h-[580px] flex flex-col">
            <div className="flex justify-between items-center mb-8">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-cyber-blue/10">
                    <BarChart3 className="w-4 h-4 text-cyber-blue" />
                  </div>
                  <h3 className="text-xs font-mono uppercase tracking-[0.2em] font-bold">{timeframe} Momentum Terminal</h3>
                </div>
                <div className="flex p-1 bg-white/[0.03] rounded-lg border border-white/5">
                  <button 
                    onClick={() => setTimeframe("5M")}
                    className={cn(
                      "tab-btn",
                      timeframe === "5M" ? "tab-btn-active" : "tab-btn-inactive"
                    )}
                  >
                    5M
                  </button>
                  <button 
                    onClick={() => setTimeframe("15M")}
                    className={cn(
                      "tab-btn",
                      timeframe === "15M" ? "tab-btn-active" : "tab-btn-inactive"
                    )}
                  >
                    15M
                  </button>
                </div>
              </div>
              <div className="flex gap-6 text-[9px] font-mono text-white/30 uppercase tracking-widest">
                <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-cyber-blue" /> Price</span>
                <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-cyber-amber" /> MA 20</span>
                <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-white border border-white/20" /> EMA 200</span>
              </div>
            </div>
            
            <div className="flex-1 w-full flex flex-col gap-4">
              {/* Price Chart */}
              <div className="h-[320px]">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={timeframe === "5M" ? (data?.klines5m || []) : (data?.klines15m || [])}>
                    <defs>
                      <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#00f0ff" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#00f0ff" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                    <XAxis 
                      dataKey="time" 
                      hide={true}
                    />
                    <YAxis 
                      domain={['auto', 'auto']}
                      tick={{ fontSize: 10, fill: "#ffffff40" }}
                      axisLine={false}
                      tickLine={false}
                      orientation="right"
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#121212", border: "1px solid #ffffff10", fontSize: "12px" }}
                      itemStyle={{ color: "#fff" }}
                      labelFormatter={(t) => formatTime(t)}
                    />
                    
                    {/* Price Area */}
                    <Area 
                      type="monotone" 
                      dataKey="close" 
                      stroke="#00f0ff" 
                      fillOpacity={1} 
                      fill="url(#colorPrice)" 
                      strokeWidth={2}
                      isAnimationActive={false}
                    />

                    {/* MA 20 Baseline */}
                    <Line 
                      type="monotone" 
                      dataKey="ma20" 
                      stroke="#fbbf24" 
                      strokeWidth={1.5} 
                      dot={false} 
                      isAnimationActive={false} 
                    />

                    {/* EMA 200 Trend */}
                    <Line 
                      type="monotone" 
                      dataKey="ema200" 
                      stroke="#ffffff" 
                      strokeWidth={1} 
                      strokeDasharray="5 5"
                      dot={false} 
                      isAnimationActive={false} 
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Volume Chart */}
              <div className="h-[100px] border-t border-white/5 pt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Volume (XRP)</span>
                </div>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={timeframe === "5M" ? (data?.klines5m || []) : (data?.klines15m || [])}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                    <XAxis 
                      dataKey="time" 
                      tickFormatter={(t) => formatTimeShort(t)}
                      tick={{ fontSize: 10, fill: "#ffffff40" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis 
                      hide={true}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#121212", border: "1px solid #ffffff10", fontSize: "12px" }}
                      itemStyle={{ color: "#fff" }}
                      labelFormatter={(t) => formatTime(t)}
                    />
                    <Bar dataKey="volume" isAnimationActive={false}>
                      {(timeframe === "5M" ? (data?.klines5m || []) : (data?.klines15m || [])).map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.isUp ? "#10b981" : "#ef4444"} fillOpacity={0.6} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Indicators Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* StochRSI */}
            <div id="indicator-stochrsi" className="glass-card p-5">
              <div className="flex justify-between items-center mb-6">
                <h4 className="text-[10px] font-mono text-white/30 uppercase tracking-widest">StochRSI (14,14,3,3)</h4>
                <div className="w-2 h-2 rounded-full bg-cyber-blue/40 animate-pulse" />
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <div className="text-2xl font-display font-bold text-cyber-blue tracking-tight">
                    {currentIndicators?.stochRSI?.k?.toFixed(2) || "0.00"}
                  </div>
                  <div className="text-[9px] font-mono text-white/20 uppercase">K-Line</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-display font-bold text-white/60 tracking-tight">
                    {currentIndicators?.stochRSI?.d?.toFixed(2) || "0.00"}
                  </div>
                  <div className="text-[9px] font-mono text-white/20 uppercase">D-Line</div>
                </div>
              </div>
              <div className="mt-6 h-1.5 w-full bg-white/[0.03] rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-cyber-blue/40 to-cyber-blue transition-all duration-700 ease-out" 
                  style={{ width: `${currentIndicators?.stochRSI?.k || 0}%` }}
                />
              </div>
            </div>

            {/* RSI */}
            <div id="indicator-rsi" className="glass-card p-5">
              <div className="flex justify-between items-center mb-6">
                <h4 className="text-[10px] font-mono text-white/30 uppercase tracking-widest">Relative Strength (14)</h4>
                <Activity className="w-3 h-3 text-white/20" />
              </div>
              <div className="flex items-baseline gap-2">
                <div className="text-4xl font-display font-bold text-white tracking-tighter">
                  {currentIndicators?.rsi?.toFixed(1) || "0.0"}
                </div>
                <div className={cn(
                  "text-[10px] font-bold px-1.5 py-0.5 rounded",
                  (currentIndicators?.rsi || 50) > 70 ? "bg-cyber-red/20 text-cyber-red" : 
                  (currentIndicators?.rsi || 50) < 30 ? "bg-cyber-green/20 text-cyber-green" : "bg-white/5 text-white/40"
                )}>
                  {(currentIndicators?.rsi || 50) > 70 ? "OVERBOUGHT" : 
                   (currentIndicators?.rsi || 50) < 30 ? "OVERSOLD" : "NEUTRAL"}
                </div>
              </div>
              <div className="mt-6 flex justify-between text-[8px] font-mono text-white/10 uppercase tracking-widest">
                <span>30</span>
                <span>50</span>
                <span>70</span>
              </div>
            </div>

            {/* Bollinger Bands */}
            <div id="indicator-bollinger" className="glass-card p-5">
              <div className="flex justify-between items-center mb-6">
                <h4 className="text-[10px] font-mono text-white/30 uppercase tracking-widest">Bollinger Bands (20,2)</h4>
                <ShieldCheck className="w-3 h-3 text-white/20" />
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="text-[9px] text-white/30 uppercase tracking-tighter">Upper Band</div>
                  <div className="font-mono text-xs text-cyber-red font-bold">
                    {currentIndicators?.bb?.upper?.toFixed(4) || "0.0000"}
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-[9px] text-white/30 uppercase tracking-tighter">Lower Band</div>
                  <div className="font-mono text-xs text-cyber-green font-bold">
                    {currentIndicators?.bb?.lower?.toFixed(4) || "0.0000"}
                  </div>
                </div>
                <div className="pt-2 border-t border-white/5 flex justify-between items-center">
                  <div className="text-[9px] text-white/30 uppercase tracking-tighter">MA 20 Baseline</div>
                  <div className="font-mono text-xs text-cyber-amber font-bold">
                    {currentIndicators?.ma20?.toFixed(4) || "0.0000"}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Ribbon Stats */}
          <div className="cyber-card p-6">
            <h3 className="text-sm font-mono uppercase tracking-widest mb-6 flex items-center gap-2">
              <Settings className="w-4 h-4 text-white/40" />
              The Ribbon Analysis
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                <div className="text-[10px] text-white/40 uppercase mb-1">EMA 5 / 24</div>
                <div className="font-mono text-sm">
                  <span className="text-cyber-blue">{currentIndicators?.ema5?.toFixed(4) || "0.0000"}</span>
                  <span className="mx-2 text-white/10">|</span>
                  <span className="text-cyber-green">{currentIndicators?.ema24?.toFixed(4) || "0.0000"}</span>
                </div>
              </div>
              <div>
                <div className="text-[10px] text-white/40 uppercase mb-1">SMA 55 / 120</div>
                <div className="font-mono text-sm">
                  <span className="text-cyber-red">{currentIndicators?.sma55?.toFixed(4) || "0.0000"}</span>
                  <span className="mx-2 text-white/10">|</span>
                  <span className="text-white/60">{currentIndicators?.sma120?.toFixed(4) || "0.0000"}</span>
                </div>
              </div>
              <div>
                <div className="text-[10px] text-white/40 uppercase mb-1">EMA 100 / 200</div>
                <div className="font-mono text-sm">
                  <span className="text-white/80">{currentIndicators?.ema100?.toFixed(4) || "0.0000"}</span>
                  <span className="mx-2 text-white/10">|</span>
                  <span className="text-white/40">{currentIndicators?.ema200?.toFixed(4) || "0.0000"}</span>
                </div>
              </div>
              <div>
                <div className="text-[10px] text-white/40 uppercase mb-1">MA 20 (Baseline)</div>
                <div className="font-mono text-sm text-amber-400">
                  {currentIndicators?.ma20?.toFixed(4) || "0.0000"}
                </div>
              </div>
            </div>
          </div>

          {/* Risk Management */}
          <div id="risk-management-console" className="glass-card p-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 rounded-lg bg-cyber-blue/10">
                <ShieldCheck className="w-4 h-4 text-cyber-blue" />
              </div>
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] font-bold">Risk Management Console</h3>
            </div>
            
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[9px] uppercase tracking-widest text-white/30 font-bold block">Trading Capital (USDT)</label>
                  <div className="relative">
                    <input 
                      type="number" 
                      value={balance} 
                      onChange={(e) => setBalance(Number(e.target.value))}
                      className="w-full bg-white/[0.02] border border-white/10 rounded-xl px-4 py-3 font-mono text-sm focus:outline-none focus:border-cyber-blue/50 focus:bg-white/[0.04] transition-all"
                    />
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] text-white/20 font-mono">USDT</div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <label className="text-[9px] uppercase tracking-widest text-white/30 font-bold">Risk Exposure (%)</label>
                    <span className="font-mono text-xs text-cyber-blue font-bold">{risk}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.1" 
                    max="5" 
                    step="0.1"
                    value={risk} 
                    onChange={(e) => setRisk(Number(e.target.value))}
                    className="w-full accent-cyber-blue h-1.5 bg-white/5 rounded-full appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-[8px] font-mono text-white/10">
                    <span>0.1%</span>
                    <span>2.5%</span>
                    <span>5.0%</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors">
                  <div className="text-[8px] text-white/30 uppercase tracking-widest mb-2">Position Size</div>
                  <div className="font-mono text-lg text-cyber-blue font-bold tracking-tighter">${riskCalc?.positionSize?.toFixed(2) || "0.00"}</div>
                </div>
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors">
                  <div className="text-[8px] text-white/30 uppercase tracking-widest mb-2">Required Margin</div>
                  <div className="font-mono text-lg text-white/80 font-bold tracking-tighter">${riskCalc?.margin?.toFixed(2) || "0.00"}</div>
                </div>
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors">
                  <div className="text-[8px] text-white/30 uppercase tracking-widest mb-2">Risk Amount</div>
                  <div className="font-mono text-lg text-cyber-red font-bold tracking-tighter">${riskCalc?.riskAmount?.toFixed(2) || "0.00"}</div>
                </div>
                <div className="p-4 rounded-xl bg-cyber-blue/[0.02] border border-cyber-blue/10 hover:bg-cyber-blue/[0.04] transition-colors">
                  <div className="text-[8px] text-cyber-blue/40 uppercase tracking-widest mb-2">Liq. Price (Est)</div>
                  <div className="font-mono text-lg text-cyber-blue font-bold tracking-tighter">${riskCalc?.liqPrice?.toFixed(4) || "0.0000"}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <footer id="app-footer" className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between gap-4 text-[10px] font-mono text-white/20">
        <div className="flex gap-6">
          <span className="flex items-center gap-1"><Info className="w-3 h-3" /> 10X LEVERAGE CAP ENABLED</span>
          <span>MEXC FUTURES EDGE API</span>
          <span>STOCHRSI CONFLUENCE V1.2</span>
        </div>
        <div className="flex gap-4">
          <a href="#" className="hover:text-white transition-colors">DOCUMENTATION</a>
          <a href="#" className="hover:text-white transition-colors">API STATUS</a>
          <span className="text-cyber-green/40">© 2026 LAKTUSDEV SENTINEL</span>
        </div>
      </footer>
    </div>
  );
}
